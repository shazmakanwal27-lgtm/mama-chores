export default async()=>new Response(process.env.VAPID_PUBLIC||'',{headers:{'content-type':'text/plain','cache-control':'no-store'}});
export const config={path:'/api/key'};
