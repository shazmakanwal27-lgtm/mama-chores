import {getStore} from '@netlify/blobs';
import webpush from 'web-push';
export default async()=>{
  const {VAPID_PUBLIC:pub,VAPID_PRIVATE:priv,VAPID_SUBJECT:sj}=process.env;
  if(!pub||!priv||!sj){console.log('Missing VAPID settings');return}
  webpush.setVapidDetails(sj,pub,priv);
  const store=getStore('subs'),now=Date.now();let sent=0;
  const {blobs}=await store.list();
  for(const {key} of blobs){
    const d=await store.get(key,{type:'json'});if(!d||!Array.isArray(d.rem))continue;
    const due=d.rem.filter(r=>r.at<=now),keep=d.rem.filter(r=>r.at>now);let gone=false;
    for(const r of due){
      if(now-r.at>6*36e5)continue;
      try{await webpush.sendNotification(d.sub,JSON.stringify({title:r.t,body:r.b,tag:r.id}),{urgency:'high',TTL:3600});sent++}
      catch(e){if(e.statusCode===404||e.statusCode===410){gone=true;break}console.log('push error',e.statusCode)}
    }
    if(gone){await store.delete(key);continue}
    if(due.length){d.rem=keep;await store.setJSON(key,d)}
    else if(now-(d.u||0)>90*864e5)await store.delete(key);
  }
  console.log('reminders sent:',sent);
};
export const config={schedule:'* * * * *'};
