import {getStore} from '@netlify/blobs';
const hash=async s=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))].map(b=>b.toString(16).padStart(2,'0')).join('');
export default async(req)=>{
  if(req.method!=='POST')return new Response('POST only',{status:405});
  let b;try{const t=await req.text();if(t.length>150000)throw 0;b=JSON.parse(t)}catch{return new Response('bad request',{status:400})}
  const sub=b&&b.sub;
  if(!sub||typeof sub.endpoint!=='string'||!sub.endpoint.startsWith('https://')||sub.endpoint.length>600||!sub.keys||typeof sub.keys.p256dh!=='string'||typeof sub.keys.auth!=='string')return new Response('bad subscription',{status:400});
  const store=getStore('subs'),k=await hash(sub.endpoint);
  if(b.off){await store.delete(k);return new Response('ok')}
  const rem=(Array.isArray(b.rem)?b.rem:[]).slice(0,400).filter(r=>r&&typeof r.id==='string'&&Number.isFinite(r.at)).map(r=>({id:r.id.slice(0,80),at:r.at,t:String(r.t||'').slice(0,100),b:String(r.b||'').slice(0,100)}));
  await store.setJSON(k,{sub:{endpoint:sub.endpoint,keys:{p256dh:sub.keys.p256dh,auth:sub.keys.auth}},rem,u:Date.now()});
  return new Response('ok');
};
export const config={path:'/api/subscribe'};
